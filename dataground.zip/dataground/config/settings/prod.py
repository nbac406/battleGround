from .base import *
import pymysql

pymysql.install_as_MySQLdb()
DEBUG = True

ALLOWED_HOSTS = ['*']

STATIC_ROOT = BASE_DIR / 'static/'

STATICFILES_DIRS = []

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dataground',
        'USER' : 'team',
        'PASSWORD' : '123',
        'HOST' : '3.37.122.17',
        'PORT' : '3306'
    }
}